<?php
$connect = mysqli_connect("localhost", "root", "", "contact-app-zoho");
