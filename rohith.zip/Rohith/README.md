# contact-app

step-1: Install and start XAMPP
step-2: add database
step-3: import database file
step-4: open localhost/harika/index.php
